import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

nome_usuario = "13leoow"
senha_usuario = "PassTT13#"

def extrair_tweet_e_sentimento(tweet):
  texto_tweet = tweet.find_element(By.CSS_SELECTOR, "div[data-testid='tweetText']").text
  sentimento = analyzer.polarity_scores(texto_tweet)
  return {"texto": texto_tweet, "sentimento": sentimento}

service = Service()
options = webdriver.ChromeOptions()
driver = webdriver.Chrome(service=service, options=options)
analyzer = SentimentIntensityAnalyzer()


driver.get("https://twitter.com/")
time.sleep(3)
login = driver.find_element(By.LINK_TEXT, "Entrar")
login.click()
time.sleep(3)
usuario = driver.find_element(By.CSS_SELECTOR, "div.css-175oi2r input")
usuario.send_keys(nome_usuario)
usuario.send_keys(Keys.ENTER)
time.sleep(3)
senha = driver.find_element(By.XPATH, "//input[@autocomplete='current-password']")
senha.send_keys(senha_usuario)
senha.send_keys(Keys.ENTER)
time.sleep(3)
campo_pesquisa = driver.find_element(By.CSS_SELECTOR, "div.css-146c3p1 input")
campo_pesquisa.send_keys("#estresse")
campo_pesquisa.send_keys(Keys.ENTER)
time.sleep(5)

lista_tweets = []
tweets = driver.find_elements(By.TAG_NAME, "article")
for tweet in tweets:
  dados_tweet = extrair_tweet_e_sentimento(tweet)
  print(dados_tweet)
  lista_tweets.append(dados_tweet)

df_tweets = pd.DataFrame(lista_tweets)
df_tweets.to_csv("tweets_estresse.csv", index=False)


driver.quit()

